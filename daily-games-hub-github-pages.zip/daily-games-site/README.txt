DAILY GAMES HUB — PUBLISH WITH GITHUB PAGES

The website is ready in index.html. To make it permanently available from a public web link:

1. Sign in to https://github.com
2. Create a new repository. Name it daily-games-hub.
3. Set the repository to Public (GitHub Pages free hosting works with public repositories).
4. Upload index.html from this folder to the repository's top level (not inside another folder), then commit the change.
5. Open the repository's Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait a minute or two. GitHub will show a site URL, usually https://YOUR-USERNAME.github.io/daily-games-hub/.
9. Open that URL in Safari on your iPhone. Tap Share → Add to Home Screen → Add.

NOTES
- The website's daily checklist is stored in the browser on the device where you use it. It does not sync between devices.
- The game buttons link to the original game websites. If a particular link has changed, edit that card's href in index.html.
- The page is a static website; no server or paid hosting is required.
